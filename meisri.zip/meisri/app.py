import pickle
from flask import Flask, request, jsonify
import numpy as np

# Load the saved model and vectorizer
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

app = Flask(_name_)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    text = data['text']
    # Preprocess the input text
    cleaned_text = preprocess_text(text)
    vectorized_text = vectorizer.transform([cleaned_text])
    # Make prediction
    prediction = model.predict(vectorized_text)[0]
    return jsonify({"prediction": "real" if prediction == 1 else "fake"})

if _name_ == '_main_':
    app.run(debug=True)
